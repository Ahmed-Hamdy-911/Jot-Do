enum MessageType {
  success,
  info,
  warning,
  error,
  defaultContent,
  customContent
}
