import 'package:hive_flutter/hive_flutter.dart';

import '../../features/home/data/models/note_model.dart';
import '../constants/app_constants.dart';

class LocalStorageService {
  // note
  static Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(NoteModelAdapter());
    await Hive.openBox<NoteModel>(AppConstants.notesStorage);

    await Hive.openBox(AppConstants.settingsStorage);
  }
}
