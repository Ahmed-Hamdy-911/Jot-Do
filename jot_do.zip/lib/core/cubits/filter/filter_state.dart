class FilterState {
  final int selectedIndex;

  const FilterState({
    this.selectedIndex = 0,
  });
}
