import 'package:flutter/material.dart';

class PickColorState {
  final Color selectedColor;

  PickColorState({required this.selectedColor});
}
