class LanguageModel {
  final String flag;
  final String key;
  final String locale;

  LanguageModel({
    required this.flag,
    required this.key,
    required this.locale,
  });
}
